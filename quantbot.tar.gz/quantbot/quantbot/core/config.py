"""YAML config loading + a synthetic market generator for offline testing.

The synthetic generator exists so you can validate the whole pipeline
(strategy -> risk -> engine -> metrics) without a broker connection. If a
strategy cannot make money on a trending synthetic series, the bug is in the
code, not the market.
"""

from __future__ import annotations

import logging
import logging.config
import os
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

from .contracts import SymbolSpec
from .risk import RiskLimits, Sizer

try:
    import yaml
except ImportError:
    yaml = None


def load_config(path: str | Path) -> dict[str, Any]:
    if yaml is None:
        raise ImportError("pip install pyyaml")
    raw = Path(path).read_text()
    # ${ENV_VAR} expansion so credentials never live in the YAML file
    raw = os.path.expandvars(raw)
    return yaml.safe_load(raw)


def build_sizer(cfg: dict) -> Sizer:
    return Sizer(**(cfg.get("sizing") or {}))


def build_limits(cfg: dict) -> RiskLimits:
    d = dict(cfg.get("limits") or {})
    for key in ("trading_hours_utc", "blocked_weekdays"):
        if key in d and d[key] is not None:
            d[key] = tuple(d[key])
    return RiskLimits(**d)


def setup_logging(level: str = "INFO", logfile: str | None = None) -> None:
    handlers: list[logging.Handler] = [logging.StreamHandler()]
    if logfile:
        Path(logfile).parent.mkdir(parents=True, exist_ok=True)
        handlers.append(logging.FileHandler(logfile, encoding="utf-8"))
    logging.basicConfig(
        level=getattr(logging, level.upper(), logging.INFO),
        format="%(asctime)s %(levelname)-7s %(name)-28s %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
        handlers=handlers,
        force=True,
    )
    logging.getLogger("matplotlib").setLevel(logging.WARNING)


# --------------------------------------------------------------------------
# Symbol specs for offline work
# --------------------------------------------------------------------------
def demo_spec(name: str, kind: str = "fx5") -> SymbolSpec:
    """Realistic Exness-like specs for offline testing.

    Verify against your own account with scripts/inspect_symbols.py before
    trusting any sizing numbers — contract sizes differ by account type.
    """
    presets = {
        # digits, point, tick_value(1 lot / point), contract, vmin, vstep, group
        "fx5": (5, 0.00001, 1.0, 100_000, 0.01, 0.01, "forex"),
        "fx3": (3, 0.001, 0.68, 100_000, 0.01, 0.01, "forex"),   # JPY pairs
        "gold": (2, 0.01, 1.0, 100, 0.01, 0.01, "metals"),
        "index": (1, 0.1, 0.1, 1, 0.1, 0.1, "indices"),
        "crypto": (2, 0.01, 0.01, 1, 0.01, 0.01, "crypto"),
    }
    d, point, tv, cs, vmin, vstep, group = presets[kind]
    return SymbolSpec(
        name=name, digits=d, point=point, tick_size=point, tick_value=tv,
        contract_size=cs, volume_min=vmin, volume_max=200.0, volume_step=vstep,
        stops_level_points=0, spread_points=12 if kind.startswith("fx") else 20,
        group=group,
    )


def synthetic_bars(
    n: int = 6000,
    start: str = "2023-01-02",
    freq: str = "1h",
    price0: float = 1.10,
    vol: float = 0.0018,
    trend_strength: float = 0.35,
    regime_len: int = 400,
    seed: int = 42,
) -> pd.DataFrame:
    """OHLC series with persistent trends and vol clustering.

    Not a market simulator — a test fixture with enough structure that
    trend/breakout logic has something to find.
    """
    rng = np.random.default_rng(seed)
    idx = pd.date_range(start, periods=n, freq=freq, tz="UTC")

    # regime-switching drift
    n_regimes = n // regime_len + 1
    drifts = rng.normal(0, trend_strength * vol, n_regimes)
    drift = np.repeat(drifts, regime_len)[:n]

    # GARCH-ish vol clustering
    sigma = np.empty(n)
    sigma[0] = vol
    shock = rng.standard_normal(n)
    for i in range(1, n):
        sigma[i] = np.sqrt(0.000001 + 0.10 * (sigma[i - 1] * shock[i - 1]) ** 2
                           + 0.88 * sigma[i - 1] ** 2)
    rets = drift + sigma * shock
    close = price0 * np.exp(np.cumsum(rets))

    open_ = np.concatenate([[price0], close[:-1]])
    wick = np.abs(rng.standard_normal(n)) * sigma * close
    high = np.maximum(open_, close) + wick
    low = np.minimum(open_, close) - wick
    df = pd.DataFrame(
        {"open": open_, "high": high, "low": low, "close": close,
         "tick_volume": rng.integers(80, 1200, n).astype(float)},
        index=idx,
    )
    df.index.name = "time"
    # weekends off, like FX
    return df[df.index.dayofweek < 5]

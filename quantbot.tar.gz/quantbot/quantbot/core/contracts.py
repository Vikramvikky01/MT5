"""Immutable data contracts shared by strategies, brokers and engines.

Nothing in here imports MetaTrader5 or pandas-heavy machinery, so it stays
usable in tests and in the backtester.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Optional

import pandas as pd


class Side(str, Enum):
    LONG = "long"
    SHORT = "short"

    @property
    def sign(self) -> int:
        return 1 if self is Side.LONG else -1

    @property
    def opposite(self) -> "Side":
        return Side.SHORT if self is Side.LONG else Side.LONG


class OrderType(str, Enum):
    MARKET = "market"
    LIMIT = "limit"   # better price than current (pullback entry)
    STOP = "stop"     # worse price than current (breakout entry)


class ExitReason(str, Enum):
    STOP = "stop"
    TARGET = "target"
    SIGNAL = "signal"          # strategy asked to close
    TIME = "time"              # max holding period
    SESSION = "session_close"
    RISK = "risk_guard"


# --------------------------------------------------------------------------
# Instrument specification
# --------------------------------------------------------------------------
@dataclass(frozen=True)
class SymbolSpec:
    """Broker-side truth about one instrument.

    Populated from MT5 `symbol_info` (see broker/mt5_broker.py) so that risk
    maths never hardcodes "1 pip = $10" style assumptions. This is what makes
    the same strategy safe on EURUSD, XAUUSD, BTCUSD and US30 alike.
    """

    name: str
    digits: int
    point: float                 # smallest price increment (0.00001 on 5-digit FX)
    tick_size: float             # SYMBOL_TRADE_TICK_SIZE (often == point)
    tick_value: float            # account-currency P/L for 1.0 lot per tick_size
    contract_size: float
    volume_min: float
    volume_max: float
    volume_step: float
    stops_level_points: int = 0   # min SL/TP distance from price, in points
    freeze_level_points: int = 0
    spread_points: float = 0.0
    filling_modes: int = 0        # bitmask from SYMBOL_FILLING_*
    group: str = "other"          # forex / metals / indices / crypto / energy
    profit_currency: str = "USD"
    swap_long: float = 0.0
    swap_short: float = 0.0
    tradable: bool = True

    # ---- derived helpers -------------------------------------------------
    @property
    def pip(self) -> float:
        """One 'pip' in price terms. FX quotes with 3/5 digits use 10 points."""
        return self.point * 10 if self.digits in (3, 5) else self.point

    @property
    def min_stop_distance(self) -> float:
        """Broker-enforced minimum distance between price and SL/TP."""
        return self.stops_level_points * self.point

    @property
    def spread(self) -> float:
        return self.spread_points * self.point

    def round_price(self, price: float) -> float:
        if self.tick_size > 0:
            price = round(price / self.tick_size) * self.tick_size
        return round(price, self.digits)

    def round_volume(self, volume: float) -> float:
        """Round *down* to a valid lot size, then clamp. Down, never up:
        rounding up silently increases risk beyond what was authorised."""
        if self.volume_step <= 0:
            return max(0.0, volume)
        steps = math.floor(volume / self.volume_step + 1e-9)
        vol = steps * self.volume_step
        vol = round(vol, 8)
        if vol < self.volume_min:
            return 0.0
        return min(vol, self.volume_max)

    def money_per_lot(self, price_distance: float) -> float:
        """Account-currency value of `price_distance` for one lot."""
        if self.tick_size <= 0:
            return 0.0
        return abs(price_distance) / self.tick_size * self.tick_value


# --------------------------------------------------------------------------
# Orders / signals
# --------------------------------------------------------------------------
@dataclass
class StopSpec:
    """A stop-loss level plus the state its policy needs to evolve it."""

    price: float
    kind: str = "static"
    state: dict[str, Any] = field(default_factory=dict)


@dataclass
class TargetSpec:
    price: float
    volume_fraction: float = 1.0   # portion of the *original* position
    label: str = "tp"
    filled: bool = False


@dataclass
class Signal:
    """What a strategy emits. Sizing is deliberately NOT the strategy's job."""

    symbol: str
    side: Side
    strategy: str
    order_type: OrderType = OrderType.MARKET
    entry_price: Optional[float] = None      # required for LIMIT/STOP
    stop: Optional[StopSpec] = None
    targets: list[TargetSpec] = field(default_factory=list)
    confidence: float = 1.0                  # 0..1, ML probability etc.
    risk_multiplier: float = 1.0             # scales risk_per_trade
    max_bars_in_trade: Optional[int] = None
    tag: str = ""
    meta: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if self.order_type is not OrderType.MARKET and self.entry_price is None:
            raise ValueError(f"{self.order_type} signal needs an entry_price")
        if self.stop is None:
            raise ValueError("every signal must carry a stop — no exceptions")


@dataclass
class Position:
    """An open (or partially closed) trade, broker-agnostic."""

    id: str
    symbol: str
    side: Side
    volume: float
    entry_price: float
    entry_time: datetime
    strategy: str
    stop: StopSpec
    targets: list[TargetSpec] = field(default_factory=list)
    initial_volume: float = 0.0
    initial_stop: float = 0.0
    realized_pnl: float = 0.0
    commission: float = 0.0
    swap: float = 0.0
    bars_held: int = 0
    max_favourable: float = 0.0   # best price reached (for trailing / MFE)
    max_adverse: float = 0.0
    meta: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        self.initial_volume = self.initial_volume or self.volume
        self.initial_stop = self.initial_stop or self.stop.price
        self.max_favourable = self.max_favourable or self.entry_price
        self.max_adverse = self.max_adverse or self.entry_price

    @property
    def risk_distance(self) -> float:
        """Initial stop distance in price = 1R. The unit for all R maths."""
        return abs(self.entry_price - self.initial_stop)

    def r_multiple(self, price: float) -> float:
        if self.risk_distance <= 0:
            return 0.0
        return self.side.sign * (price - self.entry_price) / self.risk_distance

    def unrealized(self, price: float, spec: SymbolSpec) -> float:
        """Open P/L in account currency (sign-aware, scaled by lots)."""
        gross_per_lot = spec.money_per_lot(price - self.entry_price)
        direction = 1 if (price - self.entry_price) * self.side.sign >= 0 else -1
        return direction * gross_per_lot * self.volume

    def touches_stop(self, high: float, low: float) -> bool:
        return low <= self.stop.price if self.side is Side.LONG else high >= self.stop.price


@dataclass
class Fill:
    position_id: str
    symbol: str
    side: Side
    volume: float
    price: float
    time: datetime
    reason: str
    pnl: float = 0.0
    commission: float = 0.0
    r_multiple: float = 0.0
    strategy: str = ""


@dataclass
class AccountState:
    balance: float
    equity: float
    margin: float = 0.0
    free_margin: float = 0.0
    currency: str = "USD"
    leverage: int = 100


@dataclass
class MarketSnapshot:
    """Everything a strategy is allowed to see at decision time.

    `bars` contains ONLY closed candles — the engine drops the forming bar
    before building the snapshot. That single rule kills most look-ahead bugs.
    """

    symbol: str
    timeframe: str
    bars: pd.DataFrame            # index=UTC datetime, cols: open/high/low/close/volume
    spec: SymbolSpec
    server_time: datetime
    bid: float
    ask: float
    account: AccountState
    open_positions: list[Position] = field(default_factory=list)
    features: Optional[pd.DataFrame] = None   # strategy-precomputed columns

    @property
    def last(self) -> pd.Series:
        return self.bars.iloc[-1]

    @property
    def price(self) -> float:
        return float(self.bars["close"].iloc[-1])

    def entry_price_for(self, side: Side) -> float:
        """Market entry crosses the spread: buy at ask, sell at bid."""
        return self.ask if side is Side.LONG else self.bid

    def positions_for(self, strategy: str | None = None) -> list[Position]:
        if strategy is None:
            return list(self.open_positions)
        return [p for p in self.open_positions if p.strategy == strategy]

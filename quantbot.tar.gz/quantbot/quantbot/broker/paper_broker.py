"""Simulated broker: same interface as MT5, driven by historical bars.

Cost model is deliberately pessimistic. A backtest that only looks good
without costs is not a strategy, it is a chart.
  * entry/exit cross the spread
  * commission per lot per side
  * slippage in points on market orders
  * when a bar's range contains BOTH the stop and a target, the STOP fills
    first (we cannot see intrabar order without tick data)
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from datetime import datetime

import pandas as pd

from ..core.contracts import (
    AccountState,
    Fill,
    Position,
    Side,
    Signal,
    StopSpec,
    SymbolSpec,
)
from .base import Broker

log = logging.getLogger(__name__)


@dataclass
class CostModel:
    spread_points: dict[str, float] = field(default_factory=lambda: {"default": 12.0})
    commission_per_lot: dict[str, float] = field(default_factory=lambda: {"default": 7.0})
    slippage_points: float = 2.0
    swap_per_day_pct: float = 0.0

    def spread(self, group: str) -> float:
        return self.spread_points.get(group, self.spread_points.get("default", 12.0))

    def commission(self, group: str) -> float:
        return self.commission_per_lot.get(
            group, self.commission_per_lot.get("default", 7.0)
        )


class PaperBroker(Broker):
    """Bar-replay broker. The backtester advances `self.cursor`."""

    def __init__(
        self,
        data: dict[str, pd.DataFrame],
        specs: dict[str, SymbolSpec],
        starting_balance: float = 10_000.0,
        costs: CostModel | None = None,
        currency: str = "USD",
    ):
        self.data = data
        self.specs = specs
        self.costs = costs or CostModel()
        self.balance = starting_balance
        self.currency = currency
        self.cursor: dict[str, int] = {s: 0 for s in data}
        self.now: datetime | None = None
        self._positions: dict[str, Position] = {}
        self._next_id = 1
        self.fills: list[Fill] = []
        self.equity_curve: list[tuple[datetime, float]] = []

    # ========================================================= market data
    def symbols(self) -> list[str]:
        return list(self.data)

    def spec(self, symbol: str) -> SymbolSpec:
        base = self.specs[symbol]
        # inject the simulated spread so risk code sees a realistic floor
        return SymbolSpec(**{**base.__dict__, "spread_points": self.costs.spread(base.group)})

    def bars(self, symbol: str, timeframe: str, count: int) -> pd.DataFrame:
        i = self.cursor[symbol]
        lo = max(0, i - count + 1)
        return self.data[symbol].iloc[lo : i + 1]

    def current_bar(self, symbol: str) -> pd.Series:
        return self.data[symbol].iloc[self.cursor[symbol]]

    def tick(self, symbol: str) -> tuple[float, float]:
        spec = self.spec(symbol)
        close = float(self.current_bar(symbol)["close"])
        half = spec.spread_points * spec.point / 2
        return close - half, close + half

    def server_time(self) -> datetime:
        return self.now or datetime.now()

    # ============================================================== account
    def account(self) -> AccountState:
        eq = self.balance + sum(
            p.unrealized(float(self.current_bar(p.symbol)["close"]), self.spec(p.symbol))
            for p in self._positions.values()
        )
        return AccountState(balance=self.balance, equity=eq, currency=self.currency)

    def positions(self) -> list[Position]:
        return list(self._positions.values())

    # ============================================================ execution
    def open(self, signal: Signal, volume: float) -> Position | None:
        spec = self.spec(signal.symbol)
        bid, ask = self.tick(signal.symbol)
        slip = self.costs.slippage_points * spec.point
        price = (ask + slip) if signal.side is Side.LONG else (bid - slip)
        price = spec.round_price(price)

        comm = self.costs.commission(spec.group) * volume
        self.balance -= comm

        pid = f"P{self._next_id}"
        self._next_id += 1
        pos = Position(
            id=pid,
            symbol=signal.symbol,
            side=signal.side,
            volume=volume,
            entry_price=price,
            entry_time=self.server_time(),
            strategy=signal.strategy,
            stop=StopSpec(price=spec.round_price(signal.stop.price), kind=signal.stop.kind),
            targets=[t for t in signal.targets],
            initial_volume=volume,
            initial_stop=spec.round_price(signal.stop.price),
            commission=comm,
            meta=dict(signal.meta),
        )
        self._positions[pid] = pos
        return pos

    def modify_stop(self, position: Position, stop_price: float) -> bool:
        spec = self.spec(position.symbol)
        new = spec.round_price(stop_price)
        # ratchet only
        if position.side is Side.LONG and new <= position.stop.price:
            return False
        if position.side is Side.SHORT and new >= position.stop.price:
            return False
        position.stop.price = new
        return True

    def close(
        self,
        position: Position,
        volume: float | None = None,
        reason: str = "manual",
        price: float | None = None,
    ) -> Fill | None:
        spec = self.spec(position.symbol)
        vol = min(position.volume, spec.round_volume(volume or position.volume))
        if vol <= 0:
            vol = position.volume     # allow closing sub-min remainders

        if price is None:
            bid, ask = self.tick(position.symbol)
            slip = self.costs.slippage_points * spec.point
            price = (bid - slip) if position.side is Side.LONG else (ask + slip)
        price = spec.round_price(price)

        move = (price - position.entry_price) * position.side.sign
        pnl = spec.money_per_lot(move) * vol * (1 if move >= 0 else -1)
        comm = self.costs.commission(spec.group) * vol
        self.balance += pnl - comm
        position.realized_pnl += pnl
        position.commission += comm
        position.volume = round(position.volume - vol, 8)

        fill = Fill(
            position_id=position.id, symbol=position.symbol, side=position.side,
            volume=vol, price=price, time=self.server_time(), reason=reason,
            pnl=pnl - comm, commission=comm,
            r_multiple=position.r_multiple(price), strategy=position.strategy,
        )
        self.fills.append(fill)
        if position.volume <= 1e-9:
            self._positions.pop(position.id, None)
        return fill

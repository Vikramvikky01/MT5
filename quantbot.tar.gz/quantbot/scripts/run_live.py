#!/usr/bin/env python
"""Live / dry-run trading.

    python scripts/run_live.py                  # honours broker.dry_run in YAML
    python scripts/run_live.py --live           # explicitly arm real orders
    python scripts/run_live.py --paper          # simulated broker, live prices off

Run it in dry_run for at least a few days first. The log will show exactly
which orders WOULD have been sent, with sizes and stops.
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from quantbot.core.config import build_limits, build_sizer, load_config, setup_logging
from quantbot.engine.live import LiveConfig, LiveEngine
from quantbot.strategy.base import build_strategy


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="configs/config.yaml")
    ap.add_argument("--live", action="store_true", help="disable dry_run")
    ap.add_argument("--paper", action="store_true")
    args = ap.parse_args()

    cfg = load_config(args.config)
    lg = cfg.get("logging", {})
    setup_logging(lg.get("level", "INFO"), lg.get("file"))

    strategies = [
        build_strategy(sc) for sc in cfg["strategies"] if sc.get("enabled", True)
    ]
    if not strategies:
        print("no enabled strategies", file=sys.stderr)
        return 1

    from quantbot.broker.mt5_broker import Mt5Broker

    b = cfg["broker"]
    dry = b.get("dry_run", True) and not args.live
    broker = Mt5Broker(
        login=int(b["login"]) if b.get("login") else None,
        password=b.get("password"),
        server=b.get("server"),
        terminal_path=b.get("terminal_path"),
        magic_base=b.get("magic_base", 770000),
        deviation_points=b.get("deviation_points", 20),
        dry_run=dry,
    )
    broker.connect()

    # ---- universe -----------------------------------------------------
    u = cfg["universe"]
    if (u.get("auto") or {}).get("enabled"):
        a = u["auto"]
        candidates = broker.symbols(groups=tuple(a.get("groups", ())))
        universe = []
        for s in candidates:
            spec = broker.spec(s)
            if spec.spread_points <= a.get("max_spread_points", 1e9):
                universe.append(s)
            if len(universe) >= a.get("max_symbols", 30):
                break
    else:
        universe = [broker.resolve_symbol(s) for s in u["symbols"]]

    print(f"universe ({len(universe)}): {', '.join(universe)}")
    if dry:
        print("\n*** DRY RUN — no orders will be sent. Use --live to arm. ***\n")

    lv = cfg.get("live", {})
    engine = LiveEngine(
        broker=broker,
        strategies=strategies,
        sizer=build_sizer(cfg),
        limits=build_limits(cfg),
        universe=universe,
        config=LiveConfig(
            poll_seconds=lv.get("poll_seconds", 5),
            heartbeat_minutes=lv.get("heartbeat_minutes", 30),
            state_path=lv.get("state_path", "state/live_state.json"),
            close_on_shutdown=lv.get("close_on_shutdown", False),
        ),
    )
    engine.run()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

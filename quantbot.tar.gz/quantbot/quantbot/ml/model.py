"""Model training, evaluation and persistence.

The model answers one narrow question: *given these features, will the profit
barrier be hit before the stop barrier?* Narrow beats clever — a classifier
whose target matches the engine's actual exit rules can be trusted; a
"predict tomorrow's price" regressor cannot.
"""

from __future__ import annotations

import json
import logging
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
from sklearn.calibration import CalibratedClassifierCV
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.metrics import (
    accuracy_score,
    brier_score_loss,
    log_loss,
    precision_score,
    recall_score,
    roc_auc_score,
)

from .dataset import BarrierConfig, make_dataset, make_features, purged_walk_forward

log = logging.getLogger(__name__)


@dataclass
class TrainConfig:
    barrier: BarrierConfig = field(default_factory=BarrierConfig)
    n_splits: int = 5
    embargo: int = 48
    calibrate: bool = True
    max_iter: int = 300
    learning_rate: float = 0.05
    max_depth: int | None = 4
    min_samples_leaf: int = 40
    l2_regularization: float = 1.0
    class_weight: str | None = "balanced"
    random_state: int = 7


@dataclass
class FoldMetrics:
    fold: int
    n_train: int
    n_test: int
    auc: float
    accuracy: float
    precision: float
    recall: float
    brier: float
    logloss: float
    # Trading-relevant: what happens if we only act above the threshold?
    hit_rate_at_threshold: float
    coverage_at_threshold: float
    expectancy_r: float


def _make_estimator(cfg: TrainConfig):
    return HistGradientBoostingClassifier(
        max_iter=cfg.max_iter,
        learning_rate=cfg.learning_rate,
        max_depth=cfg.max_depth,
        min_samples_leaf=cfg.min_samples_leaf,
        l2_regularization=cfg.l2_regularization,
        class_weight=cfg.class_weight,
        early_stopping=True,
        validation_fraction=0.15,
        random_state=cfg.random_state,
    )


def evaluate_walk_forward(
    X: pd.DataFrame,
    y: pd.Series,
    aux: pd.DataFrame,
    cfg: TrainConfig,
    threshold: float = 0.55,
) -> list[FoldMetrics]:
    """Out-of-sample metrics across purged expanding windows.

    Read `expectancy_r` first. AUC of 0.55 with positive expectancy beats AUC
    of 0.65 with negative expectancy — the second one is right about trades
    that do not pay.
    """
    out: list[FoldMetrics] = []
    for i, (tr, te) in enumerate(
        purged_walk_forward(X.index, cfg.n_splits, cfg.embargo)
    ):
        Xtr, ytr = X.iloc[tr], y.iloc[tr]
        Xte, yte = X.iloc[te], y.iloc[te]
        if ytr.nunique() < 2 or yte.nunique() < 2:
            continue

        model = _make_estimator(cfg)
        model.fit(Xtr, ytr)
        prob = model.predict_proba(Xte)[:, 1]
        pred = (prob >= 0.5).astype(int)

        act = prob >= threshold
        r = aux.iloc[te]["realised_r"].to_numpy()
        expectancy = float(r[act].mean()) if act.any() else 0.0

        out.append(
            FoldMetrics(
                fold=i,
                n_train=len(tr),
                n_test=len(te),
                auc=float(roc_auc_score(yte, prob)),
                accuracy=float(accuracy_score(yte, pred)),
                precision=float(precision_score(yte, pred, zero_division=0)),
                recall=float(recall_score(yte, pred, zero_division=0)),
                brier=float(brier_score_loss(yte, prob)),
                logloss=float(log_loss(yte, prob, labels=[0, 1])),
                hit_rate_at_threshold=float(yte.to_numpy()[act].mean()) if act.any() else 0.0,
                coverage_at_threshold=float(act.mean()),
                expectancy_r=expectancy,
            )
        )
    return out


def fit_final(X: pd.DataFrame, y: pd.Series, cfg: TrainConfig):
    """Fit on everything, optionally calibrated so probabilities mean something.

    Calibration matters here because we threshold the probability AND use it
    to scale position size. An uncalibrated 0.8 that is really 0.55 will size
    up exactly when it should not.
    """
    base = _make_estimator(cfg)
    if not cfg.calibrate:
        base.fit(X, y)
        return base
    # prefit-free: CalibratedClassifierCV with a time-ordered CV is imperfect
    # but far better than raw GBM scores. cv=3 keeps folds chronological-ish.
    model = CalibratedClassifierCV(base, method="isotonic", cv=3)
    model.fit(X, y)
    return model


@dataclass
class ModelBundle:
    """Model + everything needed to reproduce inference. Never ship a bare
    pickle: without the feature order and barrier config it is unusable."""

    model: Any
    feature_columns: list[str]
    barrier: BarrierConfig
    train_config: TrainConfig
    metrics: list[FoldMetrics]
    symbols: list[str]
    timeframe: str
    trained_at: str = ""
    rows: int = 0

    def save(self, path: str | Path) -> Path:
        import joblib

        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        self.trained_at = self.trained_at or datetime.now(timezone.utc).isoformat()
        joblib.dump(self, path)
        # Human-readable sidecar for audit.
        meta = {
            "trained_at": self.trained_at,
            "rows": self.rows,
            "symbols": self.symbols,
            "timeframe": self.timeframe,
            "n_features": len(self.feature_columns),
            "barrier": asdict(self.barrier),
            "metrics": [asdict(m) for m in self.metrics],
        }
        path.with_suffix(".json").write_text(json.dumps(meta, indent=2))
        return path

    @staticmethod
    def load(path: str | Path) -> "ModelBundle":
        import joblib

        return joblib.load(Path(path))

    def predict_proba_last(self, bars: pd.DataFrame) -> float:
        """Probability for the most recent CLOSED bar. Returns nan if features
        are not ready (insufficient warmup) — callers must check."""
        feats = make_features(bars)
        row = feats.iloc[[-1]].reindex(columns=self.feature_columns)
        if row.isna().any(axis=1).iloc[0]:
            return float("nan")
        return float(self.model.predict_proba(row)[0, 1])

    def predict_proba_frame(self, bars: pd.DataFrame) -> pd.Series:
        """Vectorised probabilities for a whole history — used by backtests."""
        feats = make_features(bars).reindex(columns=self.feature_columns)
        ok = feats.notna().all(axis=1)
        out = pd.Series(np.nan, index=bars.index, dtype=float)
        if ok.any():
            out.loc[ok] = self.model.predict_proba(feats[ok])[:, 1]
        return out


def summarise(metrics: list[FoldMetrics]) -> pd.DataFrame:
    if not metrics:
        return pd.DataFrame()
    df = pd.DataFrame([asdict(m) for m in metrics])
    summary = df.drop(columns=["fold"]).mean().to_frame("mean").T
    summary.index = ["average"]
    return pd.concat([df.set_index("fold"), summary])

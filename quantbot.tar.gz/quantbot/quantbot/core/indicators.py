"""Vectorised indicators. Pure pandas/numpy — no TA-Lib, no compilers.

Every function returns a Series/DataFrame aligned to the input index and uses
only past data at each point, so the same code is valid for backtest and live.
"""

from __future__ import annotations

import numpy as np
import pandas as pd


def ema(s: pd.Series, n: int) -> pd.Series:
    return s.ewm(span=n, adjust=False, min_periods=n).mean()


def sma(s: pd.Series, n: int) -> pd.Series:
    return s.rolling(n).mean()


def true_range(df: pd.DataFrame) -> pd.Series:
    prev_close = df["close"].shift(1)
    return pd.concat(
        [
            df["high"] - df["low"],
            (df["high"] - prev_close).abs(),
            (df["low"] - prev_close).abs(),
        ],
        axis=1,
    ).max(axis=1)


def atr(df: pd.DataFrame, n: int = 14) -> pd.Series:
    """Wilder ATR (RMA smoothing), the same one MT5 draws."""
    return true_range(df).ewm(alpha=1 / n, adjust=False, min_periods=n).mean()


def rsi(s: pd.Series, n: int = 14) -> pd.Series:
    delta = s.diff()
    up = delta.clip(lower=0)
    down = -delta.clip(upper=0)
    roll_up = up.ewm(alpha=1 / n, adjust=False, min_periods=n).mean()
    roll_down = down.ewm(alpha=1 / n, adjust=False, min_periods=n).mean()
    rs = roll_up / roll_down.replace(0, np.nan)
    return (100 - 100 / (1 + rs)).fillna(50)


def adx(df: pd.DataFrame, n: int = 14) -> pd.DataFrame:
    up_move = df["high"].diff()
    down_move = -df["low"].diff()
    plus_dm = np.where((up_move > down_move) & (up_move > 0), up_move, 0.0)
    minus_dm = np.where((down_move > up_move) & (down_move > 0), down_move, 0.0)
    tr = true_range(df).ewm(alpha=1 / n, adjust=False, min_periods=n).mean()
    plus_di = 100 * pd.Series(plus_dm, index=df.index).ewm(
        alpha=1 / n, adjust=False, min_periods=n
    ).mean() / tr
    minus_di = 100 * pd.Series(minus_dm, index=df.index).ewm(
        alpha=1 / n, adjust=False, min_periods=n
    ).mean() / tr
    dx = 100 * (plus_di - minus_di).abs() / (plus_di + minus_di).replace(0, np.nan)
    return pd.DataFrame(
        {
            "plus_di": plus_di,
            "minus_di": minus_di,
            "adx": dx.ewm(alpha=1 / n, adjust=False, min_periods=n).mean(),
        }
    )


def donchian(df: pd.DataFrame, n: int = 20, shift: int = 1) -> pd.DataFrame:
    """Rolling channel. shift=1 excludes the current bar, which is what you
    want for breakout logic (otherwise the bar breaks its own high)."""
    hi = df["high"].rolling(n).max().shift(shift)
    lo = df["low"].rolling(n).min().shift(shift)
    return pd.DataFrame({"upper": hi, "lower": lo, "mid": (hi + lo) / 2})


def keltner(df: pd.DataFrame, n: int = 20, mult: float = 2.0) -> pd.DataFrame:
    mid = ema(df["close"], n)
    band = atr(df, n) * mult
    return pd.DataFrame({"mid": mid, "upper": mid + band, "lower": mid - band})


def bollinger(df: pd.DataFrame, n: int = 20, mult: float = 2.0) -> pd.DataFrame:
    mid = sma(df["close"], n)
    sd = df["close"].rolling(n).std(ddof=0)
    return pd.DataFrame(
        {"mid": mid, "upper": mid + mult * sd, "lower": mid - mult * sd,
         "width": (2 * mult * sd) / mid}
    )


def swing_high(df: pd.DataFrame, left: int = 2, right: int = 2) -> pd.Series:
    """Confirmed fractal swing highs. Uses `right` future bars, so the value
    is only known `right` bars later — we shift it forward to stay causal."""
    h = df["high"]
    cond = pd.Series(True, index=df.index)
    for i in range(1, left + 1):
        cond &= h > h.shift(i)
    for i in range(1, right + 1):
        cond &= h > h.shift(-i)
    return h.where(cond).shift(right).ffill()


def swing_low(df: pd.DataFrame, left: int = 2, right: int = 2) -> pd.Series:
    l = df["low"]
    cond = pd.Series(True, index=df.index)
    for i in range(1, left + 1):
        cond &= l < l.shift(i)
    for i in range(1, right + 1):
        cond &= l < l.shift(-i)
    return l.where(cond).shift(right).ffill()


def realized_vol(s: pd.Series, n: int = 20) -> pd.Series:
    return np.log(s / s.shift(1)).rolling(n).std(ddof=0)


def zscore(s: pd.Series, n: int = 100) -> pd.Series:
    mu = s.rolling(n).mean()
    sd = s.rolling(n).std(ddof=0)
    return (s - mu) / sd.replace(0, np.nan)


def slope(s: pd.Series, n: int = 20) -> pd.Series:
    """Normalised linear-regression slope over n bars (per-bar % change)."""
    x = np.arange(n)
    x_dev = x - x.mean()
    denom = (x_dev**2).sum()

    def _fit(window: np.ndarray) -> float:
        return float((window - window.mean()) @ x_dev / denom)

    return s.rolling(n).apply(_fit, raw=True) / s.replace(0, np.nan)


def session_of(index: pd.DatetimeIndex) -> pd.Series:
    """Rough FX session tag from UTC hour — a cheap but useful regime feature."""
    h = index.hour
    out = np.select(
        [(h >= 0) & (h < 7), (h >= 7) & (h < 12), (h >= 12) & (h < 17)],
        ["asia", "london", "overlap"],
        default="ny",
    )
    return pd.Series(out, index=index, dtype="object")

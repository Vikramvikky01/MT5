"""ML strategy: trade only when the model says the target is likelier than the stop.

Critically, the SL/TP this strategy uses must MATCH the barriers the model was
trained on, otherwise the probability is answering a different question than
the one you are betting on. `on_start` warns you if they disagree.
"""

from __future__ import annotations

import logging
from typing import Optional

import pandas as pd

from ...core import indicators as ind
from ...core.contracts import MarketSnapshot, Side, Signal
from ...ml.model import ModelBundle
from ..base import Strategy, register

log = logging.getLogger(__name__)


@register("ml_barrier")
class MlBarrier(Strategy):
    warmup = 350
    params = {
        "model_path": "models/ml_barrier.joblib",
        "long_threshold": 0.58,
        "short_threshold": 0.58,
        "short_model_path": None,   # optional separate short-side model
        "adx_min": 0.0,             # optional regime gate
        "size_by_probability": True,
    }

    def __init__(self, *a, **kw):
        super().__init__(*a, **kw)
        self._long_model: ModelBundle | None = None
        self._short_model: ModelBundle | None = None

    # ------------------------------------------------------------------
    def on_start(self) -> None:
        self._long_model = ModelBundle.load(self.p["model_path"])
        log.info(
            "loaded model %s (%d rows, trained %s)",
            self.p["model_path"], self._long_model.rows, self._long_model.trained_at,
        )
        if self.p.get("short_model_path"):
            self._short_model = ModelBundle.load(self.p["short_model_path"])

        b = self._long_model.barrier
        stop = self.stop_policy
        mult = getattr(stop, "mult", None)
        if mult is not None and abs(mult - b.loss_atr) > 1e-6:
            log.warning(
                "stop policy uses %.2f*ATR but model was trained on %.2f*ATR — "
                "the probability will not describe the trade you are placing",
                mult, b.loss_atr,
            )

    # ------------------------------------------------------------------
    def compute(self, bars: pd.DataFrame) -> pd.DataFrame:
        """Attach probabilities. Vectorised for backtests, last-row for live."""
        if self._long_model is None:
            self.on_start()

        bars["atr"] = ind.atr(bars, 14)
        bars["adx"] = ind.adx(bars, 14)["adx"]
        bars["p_long"] = self._long_model.predict_proba_frame(bars)
        if self._short_model is not None:
            bars["p_short"] = self._short_model.predict_proba_frame(bars)
        else:
            # Single-model setup: low probability of the long barrier is NOT
            # evidence for a short. Only trade shorts with a short model, or
            # set symmetric=True to accept the (weaker) inversion assumption.
            bars["p_short"] = 1.0 - bars["p_long"]

        gate = bars.adx >= self.p["adx_min"]
        bars["long_entry"] = (bars.p_long >= self.p["long_threshold"]) & gate
        bars["short_entry"] = (bars.p_short >= self.p["short_threshold"]) & gate
        bars["confidence"] = bars[["p_long", "p_short"]].max(axis=1)
        return bars

    def entry(self, snap: MarketSnapshot) -> Optional[Signal]:
        feats = self.features(snap)
        row = feats.iloc[-1]
        if not pd.notna(row.get("p_long")):
            return None    # features not warm yet

        side: Side | None = None
        prob = 0.0
        if bool(row["long_entry"]) and not self.short_only:
            side, prob = Side.LONG, float(row["p_long"])
        elif bool(row["short_entry"]) and not self.long_only:
            side, prob = Side.SHORT, float(row["p_short"])
        if side is None:
            return None

        if self.p["size_by_probability"]:
            # Map probability above threshold onto 0.5x .. 1.25x risk. Never
            # linear in probability itself: a 0.60 and a 0.95 are not 1.6x
            # apart in edge, and overbetting on model confidence is the
            # fastest way to blow up an ML system.
            thr = self.p["long_threshold" if side is Side.LONG else "short_threshold"]
            edge = (prob - thr) / max(1e-6, 1 - thr)
            confidence = 0.5 + 0.75 * min(1.0, edge)
        else:
            confidence = 1.0

        return self.make_signal(
            snap, side, confidence=confidence, meta={"probability": prob}
        )

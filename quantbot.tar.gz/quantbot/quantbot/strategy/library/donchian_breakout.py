"""Volatility-contraction breakout (Donchian + Bollinger squeeze filter)."""

from __future__ import annotations

import pandas as pd

from ...core import indicators as ind
from ..base import Strategy, register


@register("donchian_breakout")
class DonchianBreakout(Strategy):
    warmup = 300
    params = {
        "channel": 20,
        "squeeze_lookback": 100,
        "squeeze_pct": 0.4,      # width must be in the lowest 40% of its range
        "atr_period": 14,
        "min_atr_pct": 0.0002,   # skip dead markets
        "confirm_close": True,   # require the close beyond the level, not a wick
    }

    def compute(self, bars: pd.DataFrame) -> pd.DataFrame:
        p = self.p
        ch = ind.donchian(bars, p["channel"], shift=1)
        bars["upper"], bars["lower"] = ch["upper"], ch["lower"]
        bars["atr"] = ind.atr(bars, p["atr_period"])
        bb = ind.bollinger(bars, 20, 2.0)
        bars["bb_width"] = bb["width"]

        # Squeeze: current band width low relative to its own recent history.
        rank = bars.bb_width.rolling(p["squeeze_lookback"]).rank(pct=True)
        squeeze = rank.shift(1) <= p["squeeze_pct"]
        alive = (bars.atr / bars["close"]) >= p["min_atr_pct"]

        ref = bars["close"] if p["confirm_close"] else bars["high"]
        ref_dn = bars["close"] if p["confirm_close"] else bars["low"]

        bars["long_entry"] = (ref > bars.upper) & squeeze & alive
        bars["short_entry"] = (ref_dn < bars.lower) & squeeze & alive

        # Breakout failure: close back inside the channel mid.
        bars["long_exit"] = bars["close"] < ch["mid"]
        bars["short_exit"] = bars["close"] > ch["mid"]

        # Bigger breakout thrust relative to ATR -> more confidence.
        thrust = (bars["close"] - bars.upper).abs() / bars.atr.replace(0, pd.NA)
        bars["confidence"] = (0.6 + thrust.fillna(0)).clip(0.5, 1.2)
        return bars

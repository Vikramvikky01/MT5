#!/usr/bin/env python
"""Backtest runner.

    # offline, synthetic data — works with no broker at all
    python scripts/run_backtest.py --synthetic

    # real history pulled from your MT5 terminal (Windows)
    python scripts/run_backtest.py --bars 8000 --symbols EURUSD XAUUSD

    # from CSV files (time,open,high,low,close[,tick_volume])
    python scripts/run_backtest.py --csv-dir data/
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from quantbot.broker.paper_broker import CostModel
from quantbot.core.config import (
    build_limits,
    build_sizer,
    demo_spec,
    load_config,
    setup_logging,
    synthetic_bars,
)
from quantbot.engine.backtester import Backtester
from quantbot.strategy.base import build_strategy


def infer_kind(symbol: str) -> str:
    s = symbol.upper()
    if s.startswith("XAU") or s.startswith("XAG"):
        return "gold"
    if any(k in s for k in ("BTC", "ETH")):
        return "crypto"
    if "JPY" in s:
        return "fx3"
    if any(k in s for k in ("US30", "NAS", "SPX", "DE40", "UK100")):
        return "index"
    return "fx5"


def load_csv_dir(path: Path, symbols: list[str] | None) -> dict[str, pd.DataFrame]:
    out = {}
    for f in sorted(path.glob("*.csv")):
        sym = f.stem.upper()
        if symbols and sym not in [s.upper() for s in symbols]:
            continue
        df = pd.read_csv(f)
        tcol = next(c for c in df.columns if c.lower() in ("time", "date", "datetime"))
        df[tcol] = pd.to_datetime(df[tcol], utc=True)
        df = df.set_index(tcol).sort_index()
        df.columns = [c.lower() for c in df.columns]
        out[sym] = df[["open", "high", "low", "close"] +
                      (["tick_volume"] if "tick_volume" in df else [])]
    return out


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="configs/config.yaml")
    ap.add_argument("--synthetic", action="store_true")
    ap.add_argument("--csv-dir")
    ap.add_argument("--symbols", nargs="*")
    ap.add_argument("--bars", type=int, default=6000)
    ap.add_argument("--balance", type=float)
    ap.add_argument("--out", default="reports")
    args = ap.parse_args()

    cfg = load_config(args.config)
    setup_logging(cfg.get("logging", {}).get("level", "INFO"))

    symbols = args.symbols or cfg["universe"]["symbols"]

    # ---- data ---------------------------------------------------------
    if args.synthetic:
        data = {
            s: synthetic_bars(n=args.bars, seed=100 + i,
                              price0=1900.0 if infer_kind(s) == "gold" else 1.10,
                              vol=0.004 if infer_kind(s) == "gold" else 0.0018)
            for i, s in enumerate(symbols)
        }
    elif args.csv_dir:
        data = load_csv_dir(Path(args.csv_dir), symbols)
    else:
        from quantbot.broker.mt5_broker import Mt5Broker

        b = cfg["broker"]
        broker = Mt5Broker(
            login=int(b["login"]) if b.get("login") else None,
            password=b.get("password"), server=b.get("server"),
            terminal_path=b.get("terminal_path"),
        )
        broker.connect()
        tf = cfg["strategies"][0].get("timeframe", "H1")
        data, specs = {}, {}
        for s in symbols:
            data[s] = broker.bars(s, tf, args.bars)
            specs[s] = broker.spec(s)
        broker.disconnect()

    if not data:
        print("no data loaded", file=sys.stderr)
        return 1
    if "specs" not in dir():
        specs = {s: demo_spec(s, infer_kind(s)) for s in data}

    # ---- strategies ---------------------------------------------------
    strategies = [
        build_strategy(sc) for sc in cfg["strategies"] if sc.get("enabled", True)
    ]
    if not strategies:
        print("no enabled strategies in config", file=sys.stderr)
        return 1

    bt_cfg = cfg.get("backtest", {})
    costs = CostModel(**(bt_cfg.get("costs") or {}))

    bt = Backtester(
        data=data,
        specs=specs,
        strategies=strategies,
        sizer=build_sizer(cfg),
        limits=build_limits(cfg),
        costs=costs,
        starting_balance=args.balance or bt_cfg.get("starting_balance", 10_000),
    )
    result = bt.run()

    print(result)
    if not result.per_strategy.empty:
        print("\n--- per strategy ---")
        print(result.per_strategy.to_string())
    if not result.per_symbol.empty:
        print("\n--- per symbol ---")
        print(result.per_symbol.to_string())
    if result.rejections:
        print("\n--- signals blocked (top 10) ---")
        for reason, n in sorted(result.rejections.items(), key=lambda x: -x[1])[:10]:
            print(f"{n:>7}  {reason}")

    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    result.equity.to_csv(out / "equity.csv")
    if not result.fills.empty:
        result.fills.to_csv(out / "trades.csv", index=False)
    print(f"\nwrote {out}/equity.csv and {out}/trades.csv")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

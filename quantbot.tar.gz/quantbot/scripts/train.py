#!/usr/bin/env python
"""Train the triple-barrier classifier.

    python scripts/train.py --synthetic --out models/ml_h1_demo.joblib
    python scripts/train.py --symbols EURUSD --timeframe H1 --bars 30000
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from quantbot.core.config import load_config, setup_logging, synthetic_bars
from quantbot.ml.dataset import BarrierConfig, make_dataset
from quantbot.ml.model import (
    ModelBundle,
    TrainConfig,
    evaluate_walk_forward,
    fit_final,
    summarise,
)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="configs/config.yaml")
    ap.add_argument("--synthetic", action="store_true")
    ap.add_argument("--symbols", nargs="*", default=["EURUSD"])
    ap.add_argument("--timeframe", default="H1")
    ap.add_argument("--bars", type=int, default=20000)
    ap.add_argument("--side", type=int, default=1, choices=[1, -1],
                    help="1 = train the long-side model, -1 = short side")
    ap.add_argument("--threshold", type=float, default=0.58)
    ap.add_argument("--out", default="models/ml_barrier.joblib")
    args = ap.parse_args()

    cfg = load_config(args.config)
    setup_logging("INFO")
    mlc = cfg.get("ml", {})

    barrier = BarrierConfig(**{**(mlc.get("barrier") or {}), "side": args.side})
    tcfg = TrainConfig(
        barrier=barrier,
        n_splits=mlc.get("n_splits", 5),
        embargo=mlc.get("embargo", 48),
        calibrate=mlc.get("calibrate", True),
        learning_rate=mlc.get("learning_rate", 0.05),
        max_depth=mlc.get("max_depth", 4),
        min_samples_leaf=mlc.get("min_samples_leaf", 40),
    )

    # ---- data ---------------------------------------------------------
    frames = {}
    if args.synthetic:
        for i, s in enumerate(args.symbols):
            frames[s] = synthetic_bars(n=args.bars, seed=7 + i)
    else:
        from quantbot.broker.mt5_broker import Mt5Broker

        b = cfg["broker"]
        broker = Mt5Broker(
            login=int(b["login"]) if b.get("login") else None,
            password=b.get("password"), server=b.get("server"),
            terminal_path=b.get("terminal_path"),
        )
        broker.connect()
        for s in args.symbols:
            frames[s] = broker.bars(s, args.timeframe, args.bars)
            print(f"{s}: {len(frames[s])} bars {frames[s].index[0]} -> {frames[s].index[-1]}")
        broker.disconnect()

    # ---- build dataset (pooled across symbols) ------------------------
    Xs, ys, auxs = [], [], []
    for s, bars in frames.items():
        X, y, aux = make_dataset(bars, barrier)
        print(f"{s}: {len(X)} labelled rows, positive rate {y.mean():.3f}")
        Xs.append(X); ys.append(y); auxs.append(aux)

    X = pd.concat(Xs).sort_index()
    y = pd.concat(ys).sort_index()
    aux = pd.concat(auxs).sort_index()
    print(f"\npooled: {len(X)} rows x {X.shape[1]} features, "
          f"positive rate {y.mean():.3f}")

    if y.nunique() < 2:
        print("only one class present — adjust barriers", file=sys.stderr)
        return 1

    # ---- walk-forward evaluation -------------------------------------
    print("\n=== purged walk-forward (out-of-sample) ===")
    metrics = evaluate_walk_forward(X, y, aux, tcfg, args.threshold)
    if not metrics:
        print("not enough data for the requested number of splits", file=sys.stderr)
        return 1
    print(summarise(metrics).round(4).to_string())

    avg_exp = sum(m.expectancy_r for m in metrics) / len(metrics)
    avg_auc = sum(m.auc for m in metrics) / len(metrics)
    print(f"\nmean OOS AUC {avg_auc:.4f} | mean expectancy "
          f"{avg_exp:+.4f}R at p>={args.threshold}")
    if avg_exp <= 0:
        print("WARNING: negative out-of-sample expectancy. Do NOT trade this "
              "model. Change features/barriers/threshold, not the seed.")

    # ---- final fit ----------------------------------------------------
    model = fit_final(X, y, tcfg)
    bundle = ModelBundle(
        model=model, feature_columns=list(X.columns), barrier=barrier,
        train_config=tcfg, metrics=metrics, symbols=args.symbols,
        timeframe=args.timeframe, rows=len(X),
    )
    path = bundle.save(args.out)
    print(f"\nsaved {path} (+ {path.with_suffix('.json')})")
    print(f"Set stop mult={barrier.loss_atr} and target "
          f"{barrier.profit_atr / barrier.loss_atr:g}R in config to match.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

"""The broker port. Backtest, paper and live MT5 all implement this.

Because the engine only ever talks to this interface, a strategy that trades
in the backtester runs live with zero code changes — the only difference is
which object gets injected.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from datetime import datetime

import pandas as pd

from ..core.contracts import (
    AccountState,
    Fill,
    Position,
    Side,
    Signal,
    SymbolSpec,
)


class Broker(ABC):
    # ---- market data -----------------------------------------------------
    @abstractmethod
    def symbols(self) -> list[str]:
        """All tradable symbol names."""

    @abstractmethod
    def spec(self, symbol: str) -> SymbolSpec:
        """Live contract specification (refresh each call — spreads move)."""

    @abstractmethod
    def bars(self, symbol: str, timeframe: str, count: int) -> pd.DataFrame:
        """The last `count` CLOSED bars, UTC index, oldest first."""

    @abstractmethod
    def tick(self, symbol: str) -> tuple[float, float]:
        """(bid, ask)."""

    @abstractmethod
    def server_time(self) -> datetime:
        ...

    # ---- account / positions --------------------------------------------
    @abstractmethod
    def account(self) -> AccountState:
        ...

    @abstractmethod
    def positions(self) -> list[Position]:
        ...

    # ---- execution -------------------------------------------------------
    @abstractmethod
    def open(self, signal: Signal, volume: float) -> Position | None:
        ...

    @abstractmethod
    def modify_stop(self, position: Position, stop_price: float) -> bool:
        ...

    @abstractmethod
    def close(self, position: Position, volume: float | None, reason: str) -> Fill | None:
        """volume=None closes the remainder."""

    # ---- lifecycle -------------------------------------------------------
    def connect(self) -> None:
        pass

    def disconnect(self) -> None:
        pass

    def __enter__(self):
        self.connect()
        return self

    def __exit__(self, *exc):
        self.disconnect()
        return False

#!/usr/bin/env python
"""Dump your account's real contract specifications.

Run this FIRST on any new account. It tells you the actual symbol names
(EURUSD vs EURUSDm), tick values, lot steps and stop levels — the numbers all
position sizing depends on. Never assume them.

    python scripts/inspect_symbols.py --groups forex metals --csv specs.csv
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from quantbot.core.config import load_config, setup_logging


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="configs/config.yaml")
    ap.add_argument("--groups", nargs="*")
    ap.add_argument("--filter", default="", help="substring match on symbol name")
    ap.add_argument("--csv")
    args = ap.parse_args()

    cfg = load_config(args.config)
    setup_logging("WARNING")

    from quantbot.broker.mt5_broker import Mt5Broker

    b = cfg["broker"]
    broker = Mt5Broker(
        login=int(b["login"]) if b.get("login") else None,
        password=b.get("password"), server=b.get("server"),
        terminal_path=b.get("terminal_path"),
    )
    broker.connect()

    acc = broker.account()
    print(f"account currency={acc.currency} balance={acc.balance:.2f} "
          f"equity={acc.equity:.2f} leverage=1:{acc.leverage}\n")

    names = broker.symbols(groups=tuple(args.groups) if args.groups else None)
    if args.filter:
        names = [n for n in names if args.filter.upper() in n.upper()]
    print(f"{len(names)} tradable symbols\n")

    rows = []
    for n in names:
        try:
            s = broker.spec(n)
        except Exception as e:
            print(f"  {n}: {e}")
            continue
        # risk sanity: lots needed to risk 50 units of account ccy on a 20-pip stop
        dist = 20 * s.pip
        per_lot = s.money_per_lot(dist)
        rows.append({
            "symbol": s.name, "group": s.group, "digits": s.digits,
            "point": s.point, "tick_size": s.tick_size, "tick_value": s.tick_value,
            "contract": s.contract_size, "vol_min": s.volume_min,
            "vol_step": s.volume_step, "spread_pts": s.spread_points,
            "stops_lvl": s.stops_level_points, "fill_mask": s.filling_modes,
            "risk_per_lot_20pip": round(per_lot, 2),
            "lots_for_50": round(50 / per_lot, 3) if per_lot else None,
        })

    df = pd.DataFrame(rows)
    pd.set_option("display.width", 200)
    print(df.to_string(index=False))
    if args.csv:
        df.to_csv(args.csv, index=False)
        print(f"\nwrote {args.csv}")
    broker.disconnect()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

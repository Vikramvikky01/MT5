"""Trend pullback: trade with the EMA stack, enter on a shallow retracement."""

from __future__ import annotations

import pandas as pd

from ...core import indicators as ind
from ..base import Strategy, register


@register("ema_atr_trend")
class EmaAtrTrend(Strategy):
    warmup = 300
    params = {
        "fast": 21,
        "slow": 55,
        "trend": 200,
        "adx_period": 14,
        "adx_min": 18.0,
        "pullback_atr": 0.6,   # how close to fast EMA price must come
        "atr_period": 14,
    }

    def compute(self, bars: pd.DataFrame) -> pd.DataFrame:
        p = self.p
        c = bars["close"]
        bars["ema_fast"] = ind.ema(c, p["fast"])
        bars["ema_slow"] = ind.ema(c, p["slow"])
        bars["ema_trend"] = ind.ema(c, p["trend"])
        bars["atr"] = ind.atr(bars, p["atr_period"])
        bars["adx"] = ind.adx(bars, p["adx_period"])["adx"]

        up = (bars.ema_fast > bars.ema_slow) & (c > bars.ema_trend)
        down = (bars.ema_fast < bars.ema_slow) & (c < bars.ema_trend)
        strong = bars.adx >= p["adx_min"]

        # Pullback: previous bar dipped toward the fast EMA, this bar reclaims.
        near_fast = (c - bars.ema_fast).abs() <= p["pullback_atr"] * bars.atr
        reclaim_up = (bars["low"] < bars.ema_fast) & (c > bars.ema_fast)
        reclaim_dn = (bars["high"] > bars.ema_fast) & (c < bars.ema_fast)

        bars["long_entry"] = up & strong & (near_fast | reclaim_up)
        bars["short_entry"] = down & strong & (near_fast | reclaim_dn)

        # Exit when the fast/slow relationship flips.
        bars["long_exit"] = bars.ema_fast < bars.ema_slow
        bars["short_exit"] = bars.ema_fast > bars.ema_slow

        # Confidence scales risk: stronger trend -> slightly larger size.
        bars["confidence"] = (bars.adx / 40).clip(0.4, 1.2)
        return bars

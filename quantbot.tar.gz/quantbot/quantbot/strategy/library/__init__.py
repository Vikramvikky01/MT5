"""Importing this package registers every bundled strategy.

Add your own module here (or import it anywhere before build_strategy runs)
and the @register decorator makes it available to YAML configs.
"""

from . import donchian_breakout, ema_atr_trend, ml_barrier  # noqa: F401

__all__ = ["donchian_breakout", "ema_atr_trend", "ml_barrier"]
